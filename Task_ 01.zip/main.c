

#include <stdio.h>

int main()
{
    int Temp;
    printf("Enter Temperature in Degree Celcius: ");
    scanf("%d", &Temp);
    if (Temp < 15)
        printf("Cold");
    else if (Temp > 15 && Temp < 30)
        printf("Normal");
    else 
        printf("Hot");
    
}