

#include <stdio.h>

int main()
{
    int restaurantOpen, itemAvailable, balanceSufficient;
    printf("Enter Res_Open, Item_Avb, Balance\n");
    printf("Press 1 for Yes and Press 0 for No: ");
    scanf(" %d%d%d", &restaurantOpen, &itemAvailable,&balanceSufficient);
    if (restaurantOpen == 1)
        if (itemAvailable == 1)
            if (balanceSufficient == 1)
                printf("Appropriate order status");
            else
                printf("Insufficient Balance");
        else
            printf("Item not available");
    else
        printf("Restaurant Not Open");
}