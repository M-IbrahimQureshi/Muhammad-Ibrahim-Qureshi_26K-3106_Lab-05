

#include <stdio.h>

int main()
{
    int Balance;
    printf("Enter your remaining balance: ");
    scanf("%d", &Balance);
    if (Balance <= 500)
        printf("Low Balance");
    else if (Balance > 500 && Balance < 2000)
        printf("Sufficient Balance");
    else 
        printf("Premium Balance");

}