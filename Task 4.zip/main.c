
#include <stdio.h>

int main(){
    int StMarks;
    printf("Enter your Marks: ");
    scanf("%d", &StMarks);
    printf((StMarks >= 50) ? "Pass" : "Fail");

}