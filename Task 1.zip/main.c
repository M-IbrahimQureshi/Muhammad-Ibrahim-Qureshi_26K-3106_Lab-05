
#include <stdio.h>

int main()
{
    int StMarks, StAge;
    printf("Enter Student Marks: ");
    scanf("%d", &StMarks);
    printf("Enter Student Age: ");
    scanf("%d", &StAge);
    if (StAge >= 18)
        {
            if (StMarks >= 50)
                printf("Eligible for Admission");
            else
                printf("Requirement of Marks isnt fulfilled");
        }
    else
        printf("Age Requirement is Failed");
    
}